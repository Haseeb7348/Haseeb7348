﻿
namespace Library_Management_System
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btn_admin = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_stdu = new System.Windows.Forms.Button();
            this.userControl11 = new Library_Management_System.UserControl1();
            this.uc_std1 = new Library_Management_System.uc_std();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_admin
            // 
            this.btn_admin.BackColor = System.Drawing.Color.MediumBlue;
            this.btn_admin.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_admin.ForeColor = System.Drawing.Color.White;
            this.btn_admin.Location = new System.Drawing.Point(758, 101);
            this.btn_admin.Name = "btn_admin";
            this.btn_admin.Size = new System.Drawing.Size(170, 55);
            this.btn_admin.TabIndex = 0;
            this.btn_admin.Text = "Admin";
            this.btn_admin.UseVisualStyleBackColor = false;
            this.btn_admin.Click += new System.EventHandler(this.btn_admin_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.MediumBlue;
            this.label1.Location = new System.Drawing.Point(217, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(693, 65);
            this.label1.TabIndex = 1;
            this.label1.Text = "Library Managememt System";
            // 
            // btn_stdu
            // 
            this.btn_stdu.BackColor = System.Drawing.Color.MediumBlue;
            this.btn_stdu.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_stdu.ForeColor = System.Drawing.Color.White;
            this.btn_stdu.Location = new System.Drawing.Point(984, 99);
            this.btn_stdu.Name = "btn_stdu";
            this.btn_stdu.Size = new System.Drawing.Size(170, 55);
            this.btn_stdu.TabIndex = 2;
            this.btn_stdu.Text = "Student";
            this.btn_stdu.UseVisualStyleBackColor = false;
            this.btn_stdu.Click += new System.EventHandler(this.btn_std_Click);
            // 
            // userControl11
            // 
            this.userControl11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.userControl11.Location = new System.Drawing.Point(762, 177);
            this.userControl11.Name = "userControl11";
            this.userControl11.Size = new System.Drawing.Size(391, 461);
            this.userControl11.TabIndex = 3;
            // 
            // uc_std1
            // 
            this.uc_std1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uc_std1.Location = new System.Drawing.Point(760, 178);
            this.uc_std1.MyProperty = null;
            this.uc_std1.Name = "uc_std1";
            this.uc_std1.Size = new System.Drawing.Size(393, 459);
            this.uc_std1.TabIndex = 4;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Red;
            this.button1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button1.ForeColor = System.Drawing.Color.Transparent;
            this.button1.Location = new System.Drawing.Point(1200, 16);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(44, 39);
            this.button1.TabIndex = 5;
            this.button1.Text = "X";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1261, 650);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.uc_std1);
            this.Controls.Add(this.userControl11);
            this.Controls.Add(this.btn_stdu);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_admin);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_admin;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_stdu;
        private UserControl1 userControl11;
        private uc_std uc_std1;
        private System.Windows.Forms.Button button1;
    }
}

