﻿
namespace Library_Management_System
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.panel1 = new System.Windows.Forms.Panel();
            this.uc_StdReg1 = new Library_Management_System.Uc_StdReg();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_checkStatus = new System.Windows.Forms.Button();
            this.btn_returnBook = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.btn_issueBook = new System.Windows.Forms.Button();
            this.btn_stdReg = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.uc_issueBook1 = new Library_Management_System.Uc_issueBook();
            this.uc_StatusCheck1 = new Library_Management_System.Uc_StatusCheck();
            this.uc_returnBook1 = new Library_Management_System.Uc_returnBook();
            this.uc_StdReg2 = new Library_Management_System.Uc_StdReg();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MediumBlue;
            this.panel1.Controls.Add(this.uc_StdReg1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(224, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1041, 106);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // uc_StdReg1
            // 
            this.uc_StdReg1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uc_StdReg1.Location = new System.Drawing.Point(26, 12);
            this.uc_StdReg1.Name = "uc_StdReg1";
            this.uc_StdReg1.Size = new System.Drawing.Size(1072, 662);
            this.uc_StdReg1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.MediumBlue;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(257, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(500, 48);
            this.label1.TabIndex = 0;
            this.label1.Text = "Library Management System";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.MediumBlue;
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.btn_checkStatus);
            this.panel2.Controls.Add(this.btn_returnBook);
            this.panel2.Controls.Add(this.button3);
            this.panel2.Controls.Add(this.btn_issueBook);
            this.panel2.Controls.Add(this.btn_stdReg);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(220, 665);
            this.panel2.TabIndex = 1;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(31, 180);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(160, 38);
            this.label2.TabIndex = 7;
            this.label2.Text = "DashBoard";
            // 
            // btn_checkStatus
            // 
            this.btn_checkStatus.BackColor = System.Drawing.Color.MediumBlue;
            this.btn_checkStatus.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_checkStatus.ForeColor = System.Drawing.Color.Transparent;
            this.btn_checkStatus.Location = new System.Drawing.Point(15, 411);
            this.btn_checkStatus.Name = "btn_checkStatus";
            this.btn_checkStatus.Size = new System.Drawing.Size(186, 55);
            this.btn_checkStatus.TabIndex = 6;
            this.btn_checkStatus.Text = "Check Status";
            this.btn_checkStatus.UseVisualStyleBackColor = false;
            this.btn_checkStatus.Click += new System.EventHandler(this.btn_checkStatus_Click);
            // 
            // btn_returnBook
            // 
            this.btn_returnBook.BackColor = System.Drawing.Color.MediumBlue;
            this.btn_returnBook.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_returnBook.ForeColor = System.Drawing.Color.Transparent;
            this.btn_returnBook.Location = new System.Drawing.Point(17, 497);
            this.btn_returnBook.Name = "btn_returnBook";
            this.btn_returnBook.Size = new System.Drawing.Size(186, 55);
            this.btn_returnBook.TabIndex = 5;
            this.btn_returnBook.Text = "Return Book";
            this.btn_returnBook.UseVisualStyleBackColor = false;
            this.btn_returnBook.Click += new System.EventHandler(this.btn_returnBook_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.MediumBlue;
            this.button3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button3.ForeColor = System.Drawing.Color.Transparent;
            this.button3.Location = new System.Drawing.Point(15, 581);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(186, 55);
            this.button3.TabIndex = 4;
            this.button3.Text = "Logout";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // btn_issueBook
            // 
            this.btn_issueBook.BackColor = System.Drawing.Color.MediumBlue;
            this.btn_issueBook.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_issueBook.ForeColor = System.Drawing.Color.Transparent;
            this.btn_issueBook.Location = new System.Drawing.Point(15, 325);
            this.btn_issueBook.Name = "btn_issueBook";
            this.btn_issueBook.Size = new System.Drawing.Size(186, 55);
            this.btn_issueBook.TabIndex = 3;
            this.btn_issueBook.Text = "Issue Book";
            this.btn_issueBook.UseVisualStyleBackColor = false;
            this.btn_issueBook.Click += new System.EventHandler(this.btn_issueBook_Click);
            // 
            // btn_stdReg
            // 
            this.btn_stdReg.BackColor = System.Drawing.Color.MediumBlue;
            this.btn_stdReg.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_stdReg.ForeColor = System.Drawing.Color.Transparent;
            this.btn_stdReg.Location = new System.Drawing.Point(17, 240);
            this.btn_stdReg.Name = "btn_stdReg";
            this.btn_stdReg.Size = new System.Drawing.Size(186, 55);
            this.btn_stdReg.TabIndex = 2;
            this.btn_stdReg.Text = "Student Reg";
            this.btn_stdReg.UseVisualStyleBackColor = false;
            this.btn_stdReg.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(15, 23);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(186, 133);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // uc_issueBook1
            // 
            this.uc_issueBook1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uc_issueBook1.Location = new System.Drawing.Point(226, 3);
            this.uc_issueBook1.Name = "uc_issueBook1";
            this.uc_issueBook1.Size = new System.Drawing.Size(1035, 662);
            this.uc_issueBook1.TabIndex = 8;
            // 
            // uc_StatusCheck1
            // 
            this.uc_StatusCheck1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uc_StatusCheck1.Location = new System.Drawing.Point(211, -6);
            this.uc_StatusCheck1.Name = "uc_StatusCheck1";
            this.uc_StatusCheck1.Size = new System.Drawing.Size(1052, 668);
            this.uc_StatusCheck1.TabIndex = 8;
            // 
            // uc_returnBook1
            // 
            this.uc_returnBook1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uc_returnBook1.Location = new System.Drawing.Point(214, 0);
            this.uc_returnBook1.Name = "uc_returnBook1";
            this.uc_returnBook1.Size = new System.Drawing.Size(1428, 995);
            this.uc_returnBook1.TabIndex = 9;
            // 
            // uc_StdReg2
            // 
            this.uc_StdReg2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.uc_StdReg2.Location = new System.Drawing.Point(216, 0);
            this.uc_StdReg2.Name = "uc_StdReg2";
            this.uc_StdReg2.Size = new System.Drawing.Size(1136, 718);
            this.uc_StdReg2.TabIndex = 10;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1263, 665);
            this.Controls.Add(this.uc_StdReg2);
            this.Controls.Add(this.uc_returnBook1);
            this.Controls.Add(this.uc_StatusCheck1);
            this.Controls.Add(this.uc_issueBook1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_checkStatus;
        private System.Windows.Forms.Button btn_returnBook;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btn_issueBook;
        private System.Windows.Forms.Button btn_stdReg;
        private Uc_StdReg uc_StdReg1;
        private Uc_issueBook uc_issueBook1;
        private Uc_StatusCheck uc_StatusCheck1;
        private Uc_returnBook uc_returnBook1;
        private Uc_StdReg uc_StdReg2;
    }
}