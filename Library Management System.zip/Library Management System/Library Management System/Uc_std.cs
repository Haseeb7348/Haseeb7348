﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library_Management_System
{
    public partial class uc_std : UserControl
    {
        public uc_std()
        {
            InitializeComponent();
            
        }
        public uc_std MyProperty { get; set; }
        private void textBox4_MouseHover(object sender, EventArgs e)
        {
            if (txtstd_user.Text == "UserName")
            {
                txtstd_user.Text = "";
                txtstd_user.ForeColor = Color.Silver;
            }
        }

        private void textBox4_MouseLeave(object sender, EventArgs e)
        {
            if (txtstd_user.Text == "")
            {
                txtstd_user.Text = "UserName";
                txtstd_user.ForeColor = Color.Silver;
            }
        }

        internal static void ControlAccessibleObject()
        {
            throw new NotImplementedException();
        }

        private void textBox3_MouseHover(object sender, EventArgs e)
        {
            if (txtstd_pass.Text == "Password")
            {
                txtstd_pass.Text = "";
                txtstd_pass.ForeColor = Color.Silver;
            }
        }

        private void textBox3_MouseLeave(object sender, EventArgs e)
        {
            if (txtstd_pass.Text == "")
            {
                txtstd_pass.Text = "Password";
                txtstd_pass.ForeColor = Color.Silver;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            if(txtstd_user.Text == "Student" && txtstd_pass.Text == "Student")
            {
                Form2 f = new Form2();
                f.Show();
            }
            else
            {
                MessageBox.Show("Invalid Username or Password! \n Please Enter Correct Username and Password... ");
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnLogin_std_MouseHover(object sender, EventArgs e)
        {
           
        }
    }
}
